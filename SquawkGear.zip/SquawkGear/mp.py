"""
# FG multiplayer injection
# 28 Mar 2010
/***************************************************************************
 *   Copyright (C) 2010 by Ivan Ngeow                                      *
 *   rimb1991@yahoo.com                                                    *
 *             (C) 2017 by SHM   
 *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
"""

import re
import math
import xdrlib
import socket
import sys
import time

g = {	'callsign' : 'sq_gear',
	'lon' : 0,
	'lat' : 0,
	'alt' : 80,
	'pch' : 10,	# nose-up positive
	'hdg' : 60,
	'bnk' : 30 }	# clockwise positive


def geodtocart(geod):
  """ degrees and feet """
  a = 6378137.0
  e2 = math.fabs(1 - 0.9966471893352525192801545 * 0.9966471893352525192801545)
  lmbda  = math.radians(geod['lon'])
  phi    = math.radians(geod['lat'])
  h      = geod['alt'] / 3.2808399
  sphi   = math.sin(phi)
  cphi   = math.cos(phi)
  n      = a / math.sqrt(1 - e2 * sphi * sphi)
  slambda = math.sin(lmbda)
  clambda = math.cos(lmbda)
  return [	(h+n)*cphi*clambda,
		(h+n)*cphi*slambda,
		(h+n-e2*n)*sphi	]

def quat_fromEuler(z, y, x):
  """ degrees """
  zd2 = 0.5*math.radians(z)
  yd2 = 0.5*math.radians(y)
  xd2 = 0.5*math.radians(x)
  Szd2 = math.sin(zd2)
  Syd2 = math.sin(yd2)
  Sxd2 = math.sin(xd2)
  Czd2 = math.cos(zd2)
  Cyd2 = math.cos(yd2)
  Cxd2 = math.cos(xd2)
  Cxd2Czd2 = Cxd2*Czd2
  Cxd2Szd2 = Cxd2*Szd2
  Sxd2Szd2 = Sxd2*Szd2
  Sxd2Czd2 = Sxd2*Czd2
  return {	'w' : Cxd2Czd2*Cyd2 + Sxd2Szd2*Syd2,
		'x' : Sxd2Czd2*Cyd2 - Cxd2Szd2*Syd2,
		'y' : Cxd2Czd2*Syd2 + Sxd2Szd2*Cyd2,
		'z' : Cxd2Szd2*Cyd2 - Sxd2Czd2*Syd2 }

def quat_fromLonLat(lon, lat):
  """ degrees """
  zd2 = 0.5*math.radians(lon)
  yd2 = -0.25*math.pi - 0.5*math.radians(lat)
  Szd2 = math.sin(zd2)
  Syd2 = math.sin(yd2)
  Czd2 = math.cos(zd2)
  Cyd2 = math.cos(yd2)
  return {	'w' : Czd2*Cyd2,
		'x' : -Szd2*Syd2,
		'y' : Czd2*Syd2,
		'z' : Szd2*Cyd2 }

def quat_multiply(v1, v2):
  return {
    'x': v1['w']*v2['x'] + v1['x']*v2['w'] + v1['y']*v2['z'] - v1['z']*v2['y'],
    'y': v1['w']*v2['y'] - v1['x']*v2['z'] + v1['y']*v2['w'] + v1['z']*v2['x'],
    'z': v1['w']*v2['z'] + v1['x']*v2['y'] - v1['y']*v2['x'] + v1['z']*v2['w'],
    'w': v1['w']*v2['w'] - v1['x']*v2['x'] - v1['y']*v2['y'] - v1['z']*v2['z']
  }

def quat_getAngleAxis(q):
  """ returns a Vec3 """
  nrm = math.sqrt(q['x']*q['x'] + q['y']*q['y'] + q['z']*q['z'] + q['w']*q['w'])
  #if nrm <= ?limit? return 0
  rNrm = 1/nrm
  a = rNrm * q['w']
  if a > 1:
    a = 1
  if a < -1:
    a = -1
  angle = math.acos(a)
  sAng = math.sin(angle)
  #if math.fabs(sAng) < ?limit?
  if math.fabs(sAng) < 1e-16:
    return [ 1, 0, 0 ]
  else:
    angle *= 2
    d = (rNrm/sAng)*angle
  return [ d*q['x'], d*q['y'], d*q['z'] ]


def pack_header(a, callsign):
  a.pack_uint(0x46474653)	# "FGFS"
  a.pack_uint(0x00010001)	# version
  a.pack_uint(7)		# POS_DATA_ID
  a.pack_uint(232)
  a.pack_uint(0)		# ReplyAddress
  a.pack_uint(5000)		# ReplyPort
  a.pack_fstring(8, callsign)

def pack_pos(a, c, o, model, v):
  global time0
  a.pack_fstring(96, model)
  a.pack_double(time.time() - time0)
  #a.pack_double(50)		# time
  a.pack_double(7)		# lag
  a.pack_double(c[0])		# position
  a.pack_double(c[1])
  a.pack_double(c[2])
  a.pack_float(o[0])		# orientation
  a.pack_float(o[1])
  a.pack_float(o[2])
  a.pack_float(v[0])		# linearVel
  a.pack_float(v[1])
  a.pack_float(v[2])
  a.pack_float(0)		# angularVel
  a.pack_float(0)
  a.pack_float(0)
  a.pack_float(0)		# linearAccel
  a.pack_float(0)
  a.pack_float(0)
  a.pack_float(0)		# angularAccel
  a.pack_float(0)
  a.pack_float(0)
  a.pack_uint(0)		# pad to 200 bytes



##################################################

s_mp = None
mp_addr = None
mp_opened = 0
time0 = 0

def open_mp(addr):
  """ opens an unconnected UDP socket """
  # called from main loop
  global s_mp, time0, mp_opened, mp_addr

  mp_opened = 0
  mp_addr = addr
  try:
    s_mp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    #s_mp.connect(addr)
    mp_opened = 1
  except socket.error:
    s_mp = None
    print 'ERROR opening multiplayer connection to FlightGear'
  time0 = time.time()

def inject_fg(g):
  global s_mp, mp_addr

  if s_mp == None: return
  tcas = xdrlib.Packer()

  c = geodtocart(g)
  ornt = quat_getAngleAxis( quat_multiply(
		  quat_fromLonLat(g['lon'], g['lat']),
		  quat_fromEuler(g['hdg'], g['pch'], g['bnk']) ) )
  s = g['spd'] * (1852. / 3600)		# knot -> m/s
  v = [s, 0, 0]
    #v = quat_fromEuler(g['hdg'], g['pch'], 0)
    #v['x'] *= s
    #v['y'] *= s
    #v['z'] *= s
  #print v
  pack_header(tcas, g['callsign'])
  pack_pos(tcas, c, ornt, g['model'], v)

  #print g['callsign'], c, s, v

  try:
    #sys.stdout.write(tcas.get_buffer())
    i = s_mp.sendto(tcas.get_buffer(), mp_addr)
  except socket.error:
    # reset the socket on error
    s_mp.close()
    s_mp = None
    mp_opened = 0

list737 = {
  'QFA': '737/737-800-Qantas.xml',
  'AHR': '737/737-Adria.xml',
  'EIN': '737/737-AerLingus.xml',
  'AFL': '737/737-Aeroflot.xml',
  'AAF': '737/737-AigleAzur.xml',
  'DAH': '737/737-AirAlgerie.xml',
  'BER': '737/737-AirBerlin.xml',
  'ACA': '737/737-AirCanada.xml',
  'AFR': '737/737-AirFrance.xml',
  'AMC': '737/737-AirMalta.xml',
  'ANZ': '737/737-AirNewZealand.xml',
  'FJI': '737/737-AirPacific.xml',
  'TRS': '737/737-Airtran.xml',
  'ASA': '737/737-AlaskaAirlines.xml',
  'AAH': '737/737-Aloha.xml',
  'AWE': '737/737-AmericaWestAirlines.xml',
  'AAL': '737/737-American.xml',
  'BMM': '737/737-Atlasblue.xml',
  'BBD': '737/737-BlueBird.xml',
  'BAW': '737/737-BritishAirways.xml',
  'BMR': '737/737-BritishMidland.xml',
  'COA': '737/737-Continental.xml',
  'CRL': '737/737-Corsair.xml',
  'DAL': '737/737-Delta.xml',
  'ELY': '737/737-ELAL.xml',
  'EZY': '737/737-EasyJet.xml',
  'ELL': '737/737-EstonianAir.xml',
  'ECA': '737/737-EuroCypria.xml',
  'XLA': '737/737-ExcelAirways.xml',
  'HHI': '737/737-HamburgInternational.xml',
  'HLF': '737/737-HapagLoyd.xml',
  'HCY': '737/737-HeliosAirways.xml',
  'KLM': '737/737-KLM.xml',
  'LOT': '737/737-LOT.xml',
  'LDA': '737/737-LaudaAir.xml',
  'DLH': '737/737-Lufthansa.xml',
  'MAH': '737/737-Malev.xml',
  'OAL': '737/737-OlympicAirways.xml',
  'NOA': '737/737-OlympicAirways.xml',
  'PGT': '737/737-PegasusAirlines.xml',
  'QFA': '737/737-Qantas.xml',
  'RAM': '737/737-RoyalAirMaroc.xml',
  'RYR': '737/737-RyanAir.xml',
  'SAS': '737/737-ScandinavianAirlines.xml',
  'SWA': '737/737-SouthWestAirlines.xml',
  'SNB': '737/737-SterlingAirlines.xml',
  'TRA': '737/737-Transavia.xml',
  'TAR': '737/737-TunisAir.xml',
  'THY': '737/737-Turkish.xml',
  'UPS': '737/737-UPS.xml',
  'UAL': '737/737-UnitedAirlines.xml',
  'VEX': '737/737-VirginExpress.xml',
  'WJA': '737/737-WestJet.xml'
}

list320 = {
  'EIN': 'A320/A320-AerLingus.xml',
  'TAR': 'A320/A320-TunisAir.xml',
  'EIN': 'A320/A320-fb-AerLingus.xml',
  'ACA': 'A320/A320-fb-AirCanada.xml',
  'AFR': 'A320/A320-fb-AirFrance.xml',
  'AWA': 'A320/A320-fb-AmericanWestAirlines.xml',
  'BAW': 'A320/A320-fb-BritishAirways.xml',
  'BMR': 'A320/A320-fb-BritishMidland.xml',
  'EZY': 'A320/A320-fb-EasyJet.xml',
  'MSR': 'A320/A320-fb-EgyptAir.xml',
  'FIN': 'A320/A320-fb-Finnair.xml',
  'DLH': 'A320/A320-fb-Lufthansa.xml',
  'NWA': 'A320/A320-fb-NorthwestAirlines.xml',
  'QTR': 'A320/A320-fb-QatarAirways.xml',
  'SAS': 'A320/A320-fb-ScandinavianAirlines.xml',
  'TAP': 'A320/A320-fb-TAP.xml',
  'TAR': 'A320/A320-fb-TunisAir.xml',
  'USA': 'A320/A320-fb-USAirways.xml',
  'UAL': 'A320/A320-fb-UnitedAirlines.xml'
"""
  'A320/A320-fb-Adria.xml',
  'A320/A320-fb-Afriqiyah.xml',
  'A320/A320-fb-AirMalta.xml',
  'A320/A320-fb-Alitalia.xml',
  'A320/A320-fb-AmericaWestAirlines.xml',
  'A320/A320-fb-AustrianAirlines.xml',
  'A320/A320-fb-ClickAir.xml',
  'A320/A320-fb-Croatia.xml',
  'A320/A320-fb-Cyprus.xml',
  'A320/A320-fb-EdelweissAir.xml',
  'A320/A320-fb-FirstChoice.xml',
  'A320/A320-fb-FreedomAir.xml',
  'A320/A320-fb-Frontier.xml',
  'A320/A320-fb-GermanWings.xml',
  'A320/A320-fb-Iberia.xml',
  'A320/A320-fb-LTU.xml',
  'A320/A320-fb-Meridiana.xml',
  'A320/A320-fb-MyAir.xml',
  'A320/A320-fb-MyTravel.xml',
  'A320/A320-fb-NouvelAir.xml',
  'A320/A320-fb-OnurAir.xml',
  'A320/A320-fb-RoyalJordanian.xml',
  'A320/A320-fb-Sabena.xml',
  'A320/A320-fb-Scandinavian.xml',
  'A320/A320-fb-SwissAir.xml',
  'A320/A320-fb-SyrianAir.xml',
  'A320/A320-fb-TACA.xml',
  'A320/A320-fb-Volare.xml',
  'A320/A320-fb-Vueling.xml'
"""
}

def _737(cs):
  i = cs[0:3]
  if i in list737: return 'AI/Aircraft/'+list737[i]
  else: return 'AI/Aircraft/737/737.xml'

def _A320(cs):
  i = cs[0:3]
  if i in list320: return 'AI/Aircraft/'+list320[i]
  else: return 'AI/Aircraft/A320/A320-fb-set.xml'

def choose_model(str, cs):
  m = 'AI/Aircraft/737/737-Aloha.xml'	# default !
  if str.find('737') > -1: m = _737(cs)
  elif str.find('747') > -1: m = 'AI/Aircraft/747-400/747-400.xml'
  elif str.find('744') > -1: m = 'AI/Aircraft/747-400/747-400.xml'
  elif str.find('757') > -1: m = 'AI/Aircraft/757/757-set.xml'
  elif str.find('763') > -1: m = 'AI/Aircraft/767/767-set.xml'
  elif str.find('767') > -1: m = 'AI/Aircraft/767/767-set.xml'
  elif str.find('772') > -1: m = 'AI/Aircraft/777/777-set.xml'
  elif str.find('777') > -1: m = 'AI/Aircraft/777/777-set.xml'
  elif str.find('318') > -1: m = _A320(cs)
  elif str.find('319') > -1: m = _A320(cs)
  elif str.find('320') > -1: m = _A320(cs)
  elif str.find('321') > -1: m = _A320(cs)
  elif str.find('332') > -1: m = 'AI/Aircraft/A332/A332-set.xml'
  elif str.find('333') > -1: m = 'AI/Aircraft/A333/A333-set.xml'
  elif str.find('343') > -1: m = 'AI/Aircraft/A343/A343-set.xml'
  elif str.find('345') > -1: m = 'AI/Aircraft/A345/A345-set.xml'
  elif str.find('346') > -1: m = 'AI/Aircraft/A346/A346-set.xml'
  elif str.find('380') > -1: m = 'AI/Aircraft/A380/A380-Lufthansa.xml'
  elif str.find('F70') > -1: m = 'AI/Aircraft/Fokker-70/fokker70-set.xml'
  #if m.find('loha') > -1: print cs, str
  return m


def update(t):
  """ squawk.notify() sends a 'tcas ...' string here """
  # tcas {callsign engines model lat lon alt spd pbh}

  #a = t.find('{') + 1
  a = 0
  m = re.match('(\S+) (\S+) (\S+) ([-.\d]+) ([-.\d]+) ([-.\d]+) ([\d.]+) (\d+)', t[a:])
  if not m:
    #print('error', t)
    return
  g['callsign'] = m.group(1)[0:7]
  i = m.group(3)
  if i == '0': return		# don't inject if model not ready
  g['model'] = choose_model(i, m.group(1))
  g['lat'] = float(m.group(4))
  g['lon'] = float(m.group(5))
  g['alt'] = int(m.group(6))
  g['spd'] = int(m.group(7))
  pbh = int(m.group(8))
  if g['alt'] + g['spd'] + pbh == 0: return
  i = (pbh >> 22) & 0x3ff
  if i > 511: i -= 1024
  g['pch'] = -i*360./1024

  i = (pbh >> 12) & 0x3ff
  if i > 511: i -= 1024
  g['bnk'] = -i*360./1024

  i = (pbh >>  2) & 0x3ff
  g['hdg'] = i*360./1024

  inject_fg(g)

