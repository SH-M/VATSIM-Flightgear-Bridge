#!/usr/local/bin/python
"""
/***************************************************************************
 *   Copyright (C) 2010 by Ivan Ngeow                                      *
 *   		   (C) 2017 by SHM                                                 *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
"""
# SquawkGear, the VATSIM pilot client for FlightGear
# 20 Jan 2010
#
# Phase One of SquawkGear involves connecting FG to VATSIM using
# Jeroen Hoppenbrouwer's SquawkBox747 for PS1, dated 2005
# (coded pre-NDA).
#
# usage: squawkgear [-t addr,port] [-m port] [-l port]
# -t specifies the FlightGear telnet interface to connect to
#    (defaults to 127.0.0.1,5900)
# -m specifies the FlightGear multiplayer port
#    (defaults to 5000; IP is same as telnet interface above)
# -l specifies the TCP port on which to accept
#    incoming connections (0 = any; defaults to 1863)

# TODO
# handle "" in parse_Tcl
# telnet -> set weather. DONE 100414 v1.1
# FG GUI
# clean up telnet/exceptions in squawk.py


import sys
import select
import socket
import re
import time
import StringIO
import squawk
import mp


def disconnect(s):
  try:
    print squawk.client_info[s][0], 'on', s.getpeername(), 'closed the connection'
    s.shutdown(socket.SHUT_RDWR)
    s.close()
  except socket.error:
    pass
  squawk.clients.remove(s)
  del squawk.client_info[s]

def handle_client_sock(s):
  try:
    buffer = StringIO.StringIO(s.recv(4096))
    i = len(buffer.getvalue())
  except socket.error:
    i = 0
  if i == 0:
    disconnect(s)
    return

  for str in buffer:
    str = str.rstrip(' \r\n')
    if str.find('exit') == 0:
      # client disconnect
      s.send('Closing connection\n')
      disconnect(s)
      return

    if str.find('register ') == 0:
      squawk.client_info[s] = squawk.sb_register(str[9:])
      continue

    if str.find('put ') == 0:
      squawk.sb_put(str[4:])
      continue

    if str.find('get ') == 0:
      buf = squawk.sb_get(str[4:]) + '\n'
      s.send(buf)
      continue

    if str.find('notify ') == 0:
      #s.send(squawk.sb_notify(str[7:], squawk.client_info[s][0]) + '\n')
      buf = squawk.sb_notify(str[7:], s) + '\n'
      s.send(buf)
      continue

    if str.find('broadcast ') == 0:
      print str[10:]
      for i in squawk.clients: i.send(str[10:] + '\n')
      continue

    else:
      print 'Unknown command ' + str + ' from ' + squawk.client_info[s][0]
      s.send('ERROR Unknown command ' + str + '\n')

def accept_new_client(s):
  # accept new connection
  (client, addr) = s.accept()
  client.setblocking(0)
  squawk.clients.append(client)
  squawk.client_info[client] = 'Unknown', ''
  print "New connection from", client.getpeername()
  client.send('Connected to SquawkGear 1.0\n')

def handle_telnet_sock():
  # read and discard any input from telnet
  # signal a closed socket upon error
  global telnet_opened

  try:
    i = squawk.telnet.recv(512)
  except socket.error:
    i = ''
  if len(i) == 0:
    telnet_opened = 0
    squawk.telnet.close()
    squawk.telnet = None
    print 'ERROR telnet socket closed'

#####################

Quit = 0
bound = 0
telnet_opened = 0
fg_ip, fg_port, mp_port = '127.0.0.1', 5900, 5000
listen_port = 1863

print """SquawkGear 1.0
Copyright (C) 2010 Ivan Ngeow, (C) 2017 SHM
This program is free software; you may redistribute it under the terms of
the GNU General Public License.  This program has absolutely no warranty.
"""

# process commandline options
if len(sys.argv) >= 3:
  i = 1
  while i < len(sys.argv):
    if sys.argv[i] == '-t':
      i += 1
      x = sys.argv[i].index(',')
      fg_ip = sys.argv[i][0:x]
      fg_port = int(sys.argv[i][x+1:])
    if sys.argv[i] == '-m':
      i += 1
      mp_port = int(sys.argv[i])
    if sys.argv[i] == '-l':
      i += 1
      listen_port = int(sys.argv[i])
    i += 1


while bound == 0:
  # open a listening socket
  try:
    listen = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listen.setblocking(0)
    listen.bind(('', listen_port))
    listen.listen(4)
    print 'SquawkGear is listening on port', listen.getsockname()[1]
    bound += 1
  except socket.error:
    print 'error binding to port {0}. retrying in 10 sec'.format(listen_port)
    # sleep and retry
    time.sleep(10)

# some default keys
squawk.sb_put('ver 191 gea 0 flp 0 sbr 0 xpd 0000 trk 0 ps1dir {{flightgear}} \
lad 0 lam 0 las n lod 0 lom 0 los e alt 0 gnd 0 pit 0 bnk 0 hdg 0 var 0 \
com 11800 xpd 0000 hrs 0 min 0 arx {} atx {} ack {} altim 2992')

# ready
print 'SquawkGear is ready. Start FlightGear and SB747 now.\n\
Press Ctrl-C to quit.'

try:
  while Quit == 0:
    # build a list of sockets to select() on
    socklist = [listen] + squawk.clients
    if squawk.telnet: socklist.append(squawk.telnet)

    # re-connect to telnet socket if necessary (and MP)
    if telnet_opened == 0:
      telnet_opened = squawk.sb_open_telnet((fg_ip, fg_port))
      mp.open_mp((fg_ip, mp_port))
      # don't block until telnet ready
      sock_ready = select.select(socklist, [], [], 3)
    else:
      # block
      sock_ready = select.select(socklist, [], [])

    if listen in sock_ready[0]:
      accept_new_client(listen)
      sock_ready[0].remove(listen)

    if squawk.telnet in sock_ready[0]:
      sock_ready[0].remove(squawk.telnet)
      handle_telnet_sock()

    # below only for client sockets, not listen or telnet sockets !
    for s in sock_ready[0]:
      handle_client_sock(s)

except KeyboardInterrupt:
  print 'SquawkGear is shutting down'
  listen.shutdown(socket.SHUT_RDWR)
  listen.close()
