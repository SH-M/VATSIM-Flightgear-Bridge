#!/usr/local/bin/python
"""
/***************************************************************************
 *   Copyright (C) 2010 by Ivan Ngeow                                      *
 *   rimb1991@yahoo.com                                                    *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
"""

import re
import socket
import mp

# globals:
brokerdict = {}
notifydict = {}

telnet = None		# telnet socket
telnet_addr = None
clients = []
client_info = {}	# a list of (name, status) hashed by socket
arx_backlog = []
rrx_backlog = []
comms_history = ''

wxr_inject = None


def trim_braces(s):
  if s[0] == '{' and s[-1] == '}':
    return s[1:-1]
  else:
    return s

def parse_Tcl(s):
  """
  returns a dict of key, values
  """
  out = {}
  a,b,c = 0,0,0
  br = 0

  for i in s:
    if i == ' ' and br == 0:
      if c % 2 == 0:
	key = trim_braces(s[a:b])
      else:
	out[key] = trim_braces(s[a:b])
	del key
      c += 1
      a = b+1
    if i == '{':
      br += 1
    if i == '}':
      br -= 1
    b += 1

  if br == 0:
    if c % 2 == 0:
      key = trim_braces(s[a:b])
      out[key] = ''
    else:
      out[key] = trim_braces(s[a:b])

  return out


def process_FG_vars(m):
  """
  turn lat,lon into lad,lam,las,lod,lom,los
  """
  if 'lat' in m:
    f = float(m['lat'])
    a = abs(f)
    m['lad'] = str(int(a))
    m['lam'] = str((round((a - int(a)) * 6000000)))[0:-2]
    if f > 0: m['las'] = 'n'
    else: m['las'] = 's'
  if 'lon' in m:
    f = float(m['lon'])
    a = abs(f)
    m['lod'] = str(int(a))
    m['lom'] = str((round((a - int(a)) * 6000000)))[0:-2]
    if f > 0: m['los'] = 'e'
    else: m['los'] = 'w'
  if 'altim' in m:
    m['altim'] = str(int(float(m['altim'])))
  if 'com' in m:
    m['com'] = str(int(float(m['com'])))

  return m


def notif(d):
  """
  Called from sb_put() with a dict of keys:values that are updated.
  For each client in the list, build a list of keys to send out
  eg notifydict['sb747'] = ['key1', 'key2', ...]
  """
  global notifydict, brokerdict, clients, telnet, rrx_backlog, comms_history
  global wxr_inject

  for key in d.keys():
    if key in notifydict:
      for s in notifydict[key]:
	# for each client
	notifydict[s].append(key)

  for s in clients:
    if s in notifydict and len(notifydict[s]) > 0:
      out = ''
      for key in notifydict[s]:
	out += ' ' + key + ' '
	if brokerdict[key].find(' ') == -1 and len(brokerdict[key]) > 0:
	  out += brokerdict[key]
	else:
	  out += '{' + brokerdict[key] + '}'
      if len(out) > 0: s.send('data' + out + '\n')
      notifydict[s] = [ ]

  # send ATC message text to FG
  if 'rrx' in d:
    if telnet:
      try:
	telnet.send('set /sim/messages/atc ' + d['rrx'] + '\r\n')
	#telnet.send('set /sim/messages/mp-plane ' + d['rrx'] + '\r\n')
      except socket.error:
	print 'ERROR sending to telnet socket '
	rrx_backlog.append(d['rrx'])
    else:
      rrx_backlog.append(d['rrx'])
    brokerdict['rrx'] = ''

  # send METARs etc using 'ai-plane' and also to the comms box
  if 'arx' in d:
    comms_history += d['arx'] + '\n'
    if telnet:
      try:
	telnet.send('set /sim/messages/ai-plane ' + d['arx'] + '\r\n')
	telnet.send('set /sim/squawkgear/receive ' + d['arx'] + '\r\n')
      except socket.error:
	print 'ERROR sending to telnet socket '
	arx_backlog.append(d['arx'])
    else:
      arx_backlog.append(d['arx'])
    brokerdict['arx'] = ''

  # catch outgoing 'atx' (direct comms) and send to the comms box
  # clear the transmit edit bar
  if 'atx' in d and len(d['atx']) > 0:
    comms_history += d['atx'] + '\n'
    if telnet:
      try:
	#telnet.send('set /sim/squawkgear/direct-comms-history ' + comms_history + '\r\n')
	telnet.send('set /sim/squawkgear/transmit\r\n')
      except socket.error:
	print 'ERROR sending to telnet socket '

  # send traffic info to squawk_mp
  if 'tcas' in d:
    mp.update(d['tcas'])

  # catch outgoing '.wxr' command
  if 'rtx' in d:
    m = re.match('\s*.wxr\s+([\w]+)', d['rtx'])
    if m:
      wxr_inject = m.group(1).upper()

  # inject metar into FG only if user has called for it (.wxr)
  if 'sb.metar' in d and wxr_inject:
    if d['sb.metar'].find(wxr_inject) > -1:
      wxr_inject = None
      if telnet:
	try:
	  telnet.send('set /environment/metar/data ' + d['sb.metar'] + '\r\n')
	except socket.error:
	  print 'ERROR sending to telnet socket '


def sb_register(s):
  """
  returns the client name and status as a tuple
  """
  m = parse_Tcl(s)
  return m.keys()[0], m.values()[0]

def sb_put(s):
  """
  parses a list of key {value} pairs, updates brokerdict
  also build list of clients that need to be notified of updates
  """
  global brokerdict
  n = {}

  m = parse_Tcl(s)
  m = process_FG_vars(m)

  # merge m into brokerdict, building a list of keys that have changed
  # this new list is used for notif()
  for i in m:
    if i not in brokerdict or m[i] != brokerdict[i]:
      brokerdict[i] = m[i]
      n[i] = m[i]
  notif(n)

def sb_get(s):
  """
  accepts a list of keys, returns a "data ..." string
  """
  global brokerdict
  out = 'data'

  if s == 'all':
    for key in brokerdict:
      out += ' ' + key + ' '
      if brokerdict[key].find(' ') == -1 and len(brokerdict[key]) > 0:
	out += brokerdict[key]
      else:
	out += '{' + brokerdict[key] + '}'
    return out

  if s == 'status':
    out = 'clients:\n'
    for j,i in enumerate(clients):
      out += str((j, i.getpeername(), client_info[i])) + '\n'
    if telnet:
      out += 'telnet socket: ' + str((telnet.getpeername())) + '\n'
    out += 'notifys:\n'
    #out += 'notify: ' + str(notifydict.items()) + '\n'
    for i in clients:
      if i in notifydict: out += str(notifydict[i]) + '\n'
    return out.rstrip('\n')

  a = 0
  while a < len(s):
    m = re.match('\s*([\w.]+)', s[a:])
    if not m:
      break
    a += m.end(1) + 1
    key = m.group(1)
    if key in brokerdict:
      out += ' ' + key + ' '
      if brokerdict[key].find(' ') == -1 and len(brokerdict[key]) > 0:
	out += brokerdict[key]
      else:
	out += '{' + brokerdict[key] + '}'

  return out

def sb_notify(str, s):
  """
  accepts a list of keys, adds to notify dict, then sb_get(str)
  """
  global brokerdict, notifydict
  a = 0
  out = 'data'

  while a < len(str):
    m = re.match('\s*([\w.]+)', str[a:])
    if not m:
      break
    a += m.end(1) + 1
    key = m.group(1)
    if key in notifydict:
      if s not in notifydict[key]:
	notifydict[key].append(s)
    else:
      notifydict[key] = [ s ]
    if key in brokerdict:
      out += ' ' + key + ' '
      if brokerdict[key].find(' ') == -1 and len(brokerdict[key]) > 0:
	out += brokerdict[key]
      else:
	out += '{' + brokerdict[key] + '}'
  notifydict[s] = [ ]

  return out

def sb_open_telnet(a):
  """
  Opens a telnet socket to FG.
  Clears the backlog of rrx messages.
  """
  global telnet, telnet_addr, rrx_backlog, arx_backlog

  try:
    telnet = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    #telnet.setblocking(0)
    telnet.connect(a)
    i = telnet.send('data\r\n\
set /sim/atc/enabled false\r\n\
set /sim/ai-traffic/enabled false\r\n\
set /sim/squawkgear/direct-comms-history\r\n\
set /sim/squawkgear/receive\r\n\
set /sim/squawkgear/transmit\r\n\
set /instrumentation/transponder/id-code 0000\r\n')
    if len(rrx_backlog) > 0:
      for i in rrx_backlog:
	telnet.send('set /sim/messages/atc ' + i + '\r\n')
	#telnet.send('set /sim/messages/mp-plane ' + i + '\r\n')
      rrx_backlog = []
    if len(arx_backlog) > 0:
      for i in arx_backlog:
	telnet.send('set /sim/messages/ai-plane ' + i + '\r\n')
      arx_backlog = []
    telnet_addr = telnet.getpeername();
    print 'Opened telnet connection to FlightGear at', telnet_addr
    return 1
  except socket.error, msg:
    #print 'Could not connect to FlightGear telnet service. retrying', msg
    telnet = None
    return 0

